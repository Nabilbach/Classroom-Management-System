import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import StudentsManagement from './components/StudentsManagement.jsx'
import SectionsManagement from './components/SectionsManagement.jsx'
import StatisticsReports from './components/StatisticsReports.jsx'
import Scheduling from './components/Scheduling.jsx'
import SettingsComponent from './components/Settings.jsx'
import { 
  Users, 
  BookOpen, 
  Award, 
  AlertTriangle, 
  TrendingUp, 
  Calendar,
  Settings,
  Home,
  UserPlus,
  BarChart3,
  Clock,
  Search,
  Bell,
  Star,
  Target
} from 'lucide-react'
import './App.css'

function App() {
  const [activeSection, setActiveSection] = useState('home')
  const [language, setLanguage] = useState('ar') // ar for Arabic, en for English

  // Sample data for demonstration
  const stats = {
    totalSections: 6,
    totalStudents: 180,
    excellentStudents: 45,
    behaviorIssues: 8,
    badgeHolders: 67
  }

  const sections = [
    { name: 'الصف الأول', students: 30, excellent: 8, issues: 1 },
    { name: 'الصف الثاني', students: 28, excellent: 7, issues: 2 },
    { name: 'الصف الثالث', students: 32, excellent: 9, issues: 1 },
    { name: 'الصف الرابع', students: 29, excellent: 6, issues: 2 },
    { name: 'الصف الخامس', students: 31, excellent: 8, issues: 1 },
    { name: 'الصف السادس', students: 30, excellent: 7, issues: 1 }
  ]

  const aiSuggestions = [
    {
      type: 'warning',
      message: 'هناك زيادة في السلوك السيء في الصف الثاني، ربما تحتاج إلى جلسة توجيه.',
      icon: AlertTriangle,
      color: 'text-orange-600'
    },
    {
      type: 'success',
      message: 'التلميذ أحمد محمد حقق تقدماً كبيراً في الأداء، يمكنك منحه بادج تشجيع.',
      icon: Award,
      color: 'text-green-600'
    },
    {
      type: 'info',
      message: 'الصف الأول يظهر أداءً ممتازاً هذا الأسبوع، استمر في التشجيع.',
      icon: TrendingUp,
      color: 'text-blue-600'
    }
  ]

  const menuItems = [
    { id: 'home', label: 'الصفحة الرئيسية', icon: Home },
    { id: 'students', label: 'إدارة التلاميذ', icon: Users },
    { id: 'sections', label: 'إدارة الأقسام', icon: BookOpen },
    { id: 'statistics', label: 'الإحصائيات والتقارير', icon: BarChart3 },
    { id: 'schedule', label: 'جدولة الحصص', icon: Calendar },
    { id: 'settings', label: 'الإعدادات', icon: Settings }
  ]

  const renderHomePage = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">مرحباً بك في نظام إدارة الفصل الدراسي</h1>
          <p className="text-gray-600 mt-2">لوحة تحكم شاملة لإدارة التلاميذ والأقسام الدراسية</p>
        </div>
        <div className="flex items-center space-x-4 space-x-reverse">
          <Button variant="outline" size="sm" onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}>
            {language === 'ar' ? 'English' : 'العربية'}
          </Button>
          <Button variant="outline" size="sm">
            <Bell className="h-4 w-4 ml-2" />
            الإشعارات
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-600">إجمالي الأقسام</p>
                <p className="text-2xl font-bold text-blue-900">{stats.totalSections}</p>
              </div>
              <BookOpen className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-600">إجمالي التلاميذ</p>
                <p className="text-2xl font-bold text-green-900">{stats.totalStudents}</p>
              </div>
              <Users className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-yellow-600">التلاميذ المتفوقون</p>
                <p className="text-2xl font-bold text-yellow-900">{stats.excellentStudents}</p>
              </div>
              <Star className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-purple-600">حاملو البادج</p>
                <p className="text-2xl font-bold text-purple-900">{stats.badgeHolders}</p>
              </div>
              <Award className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-red-600">مشاكل سلوكية</p>
                <p className="text-2xl font-bold text-red-900">{stats.behaviorIssues}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sections Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BookOpen className="h-5 w-5 ml-2" />
            نظرة عامة على الأقسام
          </CardTitle>
          <CardDescription>
            معلومات مفصلة حول كل قسم دراسي
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sections.map((section, index) => (
              <Card key={index} className="border-l-4 border-l-blue-500">
                <CardContent className="p-4">
                  <h3 className="font-semibold text-lg mb-2">{section.name}</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">عدد التلاميذ:</span>
                      <Badge variant="secondary">{section.students}</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">المتفوقون:</span>
                      <Badge className="bg-green-100 text-green-800">{section.excellent}</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">مشاكل سلوكية:</span>
                      <Badge className="bg-red-100 text-red-800">{section.issues}</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Smart Notifications */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Bell className="h-5 w-5 ml-2 text-blue-600" />
            الإشعارات الذكية
          </CardTitle>
          <CardDescription>تنبيهات مهمة تحتاج إلى انتباهك</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center p-3 bg-red-50 border border-red-200 rounded-lg">
              <AlertTriangle className="h-5 w-5 text-red-600 ml-3" />
              <div className="flex-1">
                <p className="font-medium text-red-900">تنبيه سلوكي</p>
                <p className="text-sm text-red-700">محمد عبدالله سالم يحتاج إلى متابعة سلوكية خاصة</p>
              </div>
              <Badge className="bg-red-100 text-red-800">عاجل</Badge>
            </div>
            
            <div className="flex items-center p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <Clock className="h-5 w-5 text-yellow-600 ml-3" />
              <div className="flex-1">
                <p className="font-medium text-yellow-900">تذكير حصة</p>
                <p className="text-sm text-yellow-700">حصة الصف الثالث تبدأ خلال 15 دقيقة</p>
              </div>
              <Badge className="bg-yellow-100 text-yellow-800">قريباً</Badge>
            </div>
            
            <div className="flex items-center p-3 bg-green-50 border border-green-200 rounded-lg">
              <Award className="h-5 w-5 text-green-600 ml-3" />
              <div className="flex-1">
                <p className="font-medium text-green-900">إنجاز متميز</p>
                <p className="text-sm text-green-700">فاطمة أحمد حسن حققت أعلى نقاط هذا الأسبوع</p>
              </div>
              <Badge className="bg-green-100 text-green-800">جديد</Badge>
            </div>
            
            <div className="flex items-center p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <TrendingUp className="h-5 w-5 text-blue-600 ml-3" />
              <div className="flex-1">
                <p className="font-medium text-blue-900">تحسن ملحوظ</p>
                <p className="text-sm text-blue-700">الصف الثاني أظهر تحسناً بنسبة 15% هذا الشهر</p>
              </div>
              <Badge className="bg-blue-100 text-blue-800">إيجابي</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Target className="h-5 w-5 ml-2 text-purple-600" />
            الإجراءات السريعة
          </CardTitle>
          <CardDescription>أكثر المهام استخداماً</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button 
              variant="outline" 
              className="h-20 flex flex-col items-center justify-center space-y-2"
              onClick={() => setActiveSection('students')}
            >
              <UserPlus className="h-6 w-6 text-blue-600" />
              <span className="text-sm">إضافة تلميذ</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-20 flex flex-col items-center justify-center space-y-2"
              onClick={() => setActiveSection('schedule')}
            >
              <Calendar className="h-6 w-6 text-green-600" />
              <span className="text-sm">جدولة حصة</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-20 flex flex-col items-center justify-center space-y-2"
              onClick={() => setActiveSection('statistics')}
            >
              <BarChart3 className="h-6 w-6 text-yellow-600" />
              <span className="text-sm">عرض التقارير</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-20 flex flex-col items-center justify-center space-y-2"
              onClick={() => setActiveSection('sections')}
            >
              <BookOpen className="h-6 w-6 text-purple-600" />
              <span className="text-sm">إدارة الأقسام</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Clock className="h-5 w-5 ml-2 text-gray-600" />
            النشاط الأخير
          </CardTitle>
          <CardDescription>آخر الأنشطة في النظام</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center space-x-4 space-x-reverse">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">تم إضافة تلميذ جديد: عبدالرحمن محمد</p>
                <p className="text-xs text-gray-500">منذ 5 دقائق</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4 space-x-reverse">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">تم تحديث جدول الصف الرابع</p>
                <p className="text-xs text-gray-500">منذ 15 دقيقة</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4 space-x-reverse">
              <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">تم إنشاء تقرير شهري للأداء</p>
                <p className="text-xs text-gray-500">منذ ساعة</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4 space-x-reverse">
              <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">تم تقييم 5 تلاميذ في الصف الأول</p>
                <p className="text-xs text-gray-500">منذ ساعتين</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* AI Suggestions */}
      <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Star className="h-5 w-5 ml-2 text-purple-600" />
            اقتراحات ذكية من مانوس
          </CardTitle>
          <CardDescription>
            توصيات مخصصة لتحسين إدارة الفصل الدراسي
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-white rounded-lg border border-purple-200">
              <div className="flex items-start space-x-3 space-x-reverse">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="h-4 w-4 text-purple-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-purple-900">تحسين الأداء الأكاديمي</h4>
                  <p className="text-sm text-purple-700 mt-1">
                    يُنصح بإجراء جلسات تقوية إضافية للصف الرابع لتحسين المعدل العام من 75% إلى 80%
                  </p>
                  <Button size="sm" className="mt-2 bg-purple-600 hover:bg-purple-700">
                    تطبيق الاقتراح
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="p-4 bg-white rounded-lg border border-purple-200">
              <div className="flex items-start space-x-3 space-x-reverse">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <Users className="h-4 w-4 text-purple-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-purple-900">تحسين السلوك</h4>
                  <p className="text-sm text-purple-700 mt-1">
                    تطبيق نظام المكافآت الأسبوعية قد يحسن السلوك العام بنسبة 20%
                  </p>
                  <Button size="sm" className="mt-2 bg-purple-600 hover:bg-purple-700">
                    عرض التفاصيل
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="p-4 bg-white rounded-lg border border-purple-200">
              <div className="flex items-start space-x-3 space-x-reverse">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <Calendar className="h-4 w-4 text-purple-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-purple-900">تحسين الجدولة</h4>
                  <p className="text-sm text-purple-700 mt-1">
                    إعادة ترتيب حصص الصف الخامس لتجنب التداخل مع أنشطة أخرى
                  </p>
                  <Button size="sm" className="mt-2 bg-purple-600 hover:bg-purple-700">
                    مراجعة الجدول
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="p-4 bg-white rounded-lg border border-purple-200">
              <div className="flex items-start space-x-3 space-x-reverse">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <Award className="h-4 w-4 text-purple-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-purple-900">تحفيز المتفوقين</h4>
                  <p className="text-sm text-purple-700 mt-1">
                    إنشاء برنامج تحدي شهري للمتفوقين لزيادة الدافعية والمنافسة الإيجابية
                  </p>
                  <Button size="sm" className="mt-2 bg-purple-600 hover:bg-purple-700">
                    إنشاء البرنامج
                  </Button>
                </div>
              </div>
            </div>
            
            {aiSuggestions.map((suggestion, index) => {
              const IconComponent = suggestion.icon
              return (
                <div key={index} className="flex items-start space-x-3 space-x-reverse p-4 rounded-lg bg-gray-50 border">
                  <IconComponent className={`h-5 w-5 mt-0.5 ${suggestion.color}`} />
                  <p className="text-sm text-gray-700 flex-1">{suggestion.message}</p>
                  <Button variant="outline" size="sm">
                    تطبيق
                  </Button>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderContent = () => {
    switch (activeSection) {
      case 'home':
        return renderHomePage()
      case 'students':
        return <StudentsManagement />
      case 'sections':
        return <SectionsManagement />
      case 'statistics':
        return <StatisticsReports />
      case 'schedule':
        return <Scheduling />
      case 'settings':
        return <SettingsComponent />
      default:
        return renderHomePage()
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 flex" dir="rtl">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg border-r border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <BookOpen className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-900">إدارة الفصل</h1>
              <p className="text-sm text-gray-600">نظام ذكي</p>
            </div>
          </div>
        </div>
        
        <nav className="p-4">
          <ul className="space-y-2">
            {menuItems.map((item) => {
              const IconComponent = item.icon
              return (
                <li key={item.id}>
                  <button
                    onClick={() => setActiveSection(item.id)}
                    className={`w-full flex items-center space-x-3 space-x-reverse px-4 py-3 rounded-lg text-right transition-colors ${
                      activeSection === item.id
                        ? 'bg-blue-100 text-blue-700 border border-blue-200'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <IconComponent className="h-5 w-5" />
                    <span className="font-medium">{item.label}</span>
                  </button>
                </li>
              )
            })}
          </ul>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          {renderContent()}
        </div>
      </div>
    </div>
  )
}

export default App

