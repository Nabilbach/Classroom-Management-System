import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { 
  Users, 
  UserPlus, 
  Upload, 
  Search, 
  Filter,
  Star,
  Award,
  AlertTriangle,
  Edit,
  Trash2,
  FileSpreadsheet,
  Download
} from 'lucide-react'

const StudentsManagement = () => {
  const [students, setStudents] = useState([
    {
      id: 1,
      name: 'أحمد محمد علي',
      section: 'الصف الأول',
      idNumber: '123456789',
      participationPoints: 85,
      behaviorPoints: 90,
      homeworkPoints: 78,
      badges: ['مجتهد', 'متعاون'],
      starRating: 4,
      status: 'excellent' // excellent, normal, poor
    },
    {
      id: 2,
      name: 'فاطمة أحمد حسن',
      section: 'الصف الأول',
      idNumber: '987654321',
      participationPoints: 92,
      behaviorPoints: 95,
      homeworkPoints: 88,
      badges: ['متفوقة', 'مبدعة'],
      starRating: 5,
      status: 'excellent'
    },
    {
      id: 3,
      name: 'محمد عبدالله سالم',
      section: 'الصف الثاني',
      idNumber: '456789123',
      participationPoints: 45,
      behaviorPoints: 30,
      homeworkPoints: 40,
      badges: [],
      starRating: 2,
      status: 'poor'
    },
    {
      id: 4,
      name: 'عائشة محمود طه',
      section: 'الصف الثاني',
      idNumber: '789123456',
      participationPoints: 70,
      behaviorPoints: 75,
      homeworkPoints: 68,
      badges: ['منتظمة'],
      starRating: 3,
      status: 'normal'
    }
  ])

  const [searchTerm, setSearchTerm] = useState('')
  const [selectedSection, setSelectedSection] = useState('all')
  const [selectedStatus, setSelectedStatus] = useState('all')
  const [showAddStudent, setShowAddStudent] = useState(false)
  const [selectedStudent, setSelectedStudent] = useState(null)
  const [showEvaluation, setShowEvaluation] = useState(false)

  const sections = ['الصف الأول', 'الصف الثاني', 'الصف الثالث', 'الصف الرابع', 'الصف الخامس', 'الصف السادس']
  const availableBadges = ['مجتهد', 'متعاون', 'متفوق', 'مبدع', 'منتظم', 'مشارك', 'قائد']

  const filteredStudents = students.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         student.idNumber.includes(searchTerm)
    const matchesSection = selectedSection === 'all' || student.section === selectedSection
    const matchesStatus = selectedStatus === 'all' || student.status === selectedStatus
    
    return matchesSearch && matchesSection && matchesStatus
  })

  const getStatusColor = (status) => {
    switch (status) {
      case 'excellent': return 'bg-green-100 text-green-800 border-green-200'
      case 'poor': return 'bg-red-100 text-red-800 border-red-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusText = (status) => {
    switch (status) {
      case 'excellent': return 'متفوق'
      case 'poor': return 'يحتاج تحسين'
      default: return 'عادي'
    }
  }

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
      />
    ))
  }

  const handleFileUpload = (event) => {
    const file = event.target.files[0]
    if (file) {
      // Here you would implement Excel file parsing
      alert('سيتم تطوير خاصية رفع ملفات Excel في التحديث القادم')
    }
  }

  const handleGenerateCertificate = async (student) => {
    const badge = student.badges.length > 0 ? student.badges[0] : "Achievement";
    const date = new Date().toISOString().slice(0, 10);

    try {
      const response = await fetch("http://localhost:5000/generate-certificate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          student_name: student.name,
          badge_name: badge,
          date_awarded: date,
        }),
      });

      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `${student.name}_${badge}_Certificate.pdf`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
        alert("تم إنشاء الشهادة بنجاح!");
      } else {
        alert("فشل في إنشاء الشهادة.");
      }
    } catch (error) {
      console.error("Error generating certificate:", error);
      alert("حدث خطأ أثناء إنشاء الشهادة.");
    }
  };

  const StudentEvaluationModal = ({ student, onClose, onSave }) => {
    const [evaluation, setEvaluation] = useState({
      participationPoints: student?.participationPoints || 0,
      behaviorPoints: student?.behaviorPoints || 0,
      homeworkPoints: student?.homeworkPoints || 0,
      starRating: student?.starRating || 0,
      badges: student?.badges || []
    })

    const handleSave = () => {
      onSave(student.id, evaluation)
      onClose()
    }

    const toggleBadge = (badge) => {
      setEvaluation(prev => ({
        ...prev,
        badges: prev.badges.includes(badge)
          ? prev.badges.filter(b => b !== badge)
          : [...prev.badges, badge]
      }))
    }

    if (!student) return null

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" dir="rtl">
        <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">تقييم التلميذ: {student.name}</h2>
            <Button variant="outline" onClick={onClose}>إغلاق</Button>
          </div>

          <div className="space-y-6">
            {/* Student Info */}
            <Card>
              <CardHeader>
                <CardTitle>معلومات التلميذ</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>الاسم</Label>
                    <p className="font-medium">{student.name}</p>
                  </div>
                  <div>
                    <Label>القسم</Label>
                    <p className="font-medium">{student.section}</p>
                  </div>
                  <div>
                    <Label>رقم الهوية</Label>
                    <p className="font-medium">{student.idNumber}</p>
                  </div>
                  <div>
                    <Label>الحالة</Label>
                    <Badge className={getStatusColor(student.status)}>
                      {getStatusText(student.status)}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Points Evaluation */}
            <Card>
              <CardHeader>
                <CardTitle>تقييم النقاط</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label>نقاط المشاركة (0-100)</Label>
                    <Input
                      type="number"
                      min="0"
                      max="100"
                      value={evaluation.participationPoints}
                      onChange={(e) => setEvaluation(prev => ({
                        ...prev,
                        participationPoints: parseInt(e.target.value) || 0
                      }))}
                    />
                  </div>
                  <div>
                    <Label>نقاط السلوك (0-100)</Label>
                    <Input
                      type="number"
                      min="0"
                      max="100"
                      value={evaluation.behaviorPoints}
                      onChange={(e) => setEvaluation(prev => ({
                        ...prev,
                        behaviorPoints: parseInt(e.target.value) || 0
                      }))}
                    />
                  </div>
                  <div>
                    <Label>نقاط الأعمال المنزلية (0-100)</Label>
                    <Input
                      type="number"
                      min="0"
                      max="100"
                      value={evaluation.homeworkPoints}
                      onChange={(e) => setEvaluation(prev => ({
                        ...prev,
                        homeworkPoints: parseInt(e.target.value) || 0
                      }))}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Star Rating */}
            <Card>
              <CardHeader>
                <CardTitle>تقييم بالنجوم</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex space-x-1 space-x-reverse">
                  {Array.from({ length: 5 }, (_, i) => (
                    <button
                      key={i}
                      onClick={() => setEvaluation(prev => ({ ...prev, starRating: i + 1 }))}
                      className="focus:outline-none"
                    >
                      <Star
                        className={`h-8 w-8 ${i < evaluation.starRating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                      />
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Badges */}
            <Card>
              <CardHeader>
                <CardTitle>البادجات التشجيعية</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {availableBadges.map(badge => (
                    <button
                      key={badge}
                      onClick={() => toggleBadge(badge)}
                      className={`px-3 py-1 rounded-full text-sm border transition-colors ${
                        evaluation.badges.includes(badge)
                          ? 'bg-blue-100 text-blue-800 border-blue-200'
                          : 'bg-gray-100 text-gray-600 border-gray-200 hover:bg-gray-200'
                      }`}
                    >
                      {badge}
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex justify-end space-x-4 space-x-reverse">
              <Button variant="outline" onClick={onClose}>إلغاء</Button>
              <Button onClick={handleSave}>حفظ التقييم</Button>
              <Button onClick={() => handleGenerateCertificate(student)}>إنشاء شهادة</Button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const AddStudentModal = ({ onClose, onSave }) => {
    const [newStudent, setNewStudent] = useState({
      name: '',
      section: '',
      idNumber: '',
      participationPoints: 0,
      behaviorPoints: 0,
      homeworkPoints: 0,
      badges: [],
      starRating: 0
    })

    const handleSave = () => {
      if (newStudent.name && newStudent.section && newStudent.idNumber) {
        const student = {
          ...newStudent,
          id: Date.now(),
          status: 'normal'
        }
        onSave(student)
        onClose()
      }
    }

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" dir="rtl">
        <div className="bg-white rounded-lg p-6 w-full max-w-md">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold">إضافة تلميذ جديد</h2>
            <Button variant="outline" onClick={onClose}>إغلاق</Button>
          </div>

          <div className="space-y-4">
            <div>
              <Label>اسم التلميذ</Label>
              <Input
                value={newStudent.name}
                onChange={(e) => setNewStudent(prev => ({ ...prev, name: e.target.value }))}
                placeholder="أدخل اسم التلميذ"
              />
            </div>
            <div>
              <Label>القسم</Label>
              <select
                className="w-full p-2 border rounded-md"
                value={newStudent.section}
                onChange={(e) => setNewStudent(prev => ({ ...prev, section: e.target.value }))}
              >
                <option value="">اختر القسم</option>
                {sections.map(section => (
                  <option key={section} value={section}>{section}</option>
                ))}
              </select>
            </div>
            <div>
              <Label>رقم الهوية</Label>
              <Input
                value={newStudent.idNumber}
                onChange={(e) => setNewStudent(prev => ({ ...prev, idNumber: e.target.value }))}
                placeholder="أدخل رقم الهوية"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-4 space-x-reverse mt-6">
            <Button variant="outline" onClick={onClose}>إلغاء</Button>
            <Button onClick={handleSave}>إضافة التلميذ</Button>
          </div>
        </div>
      </div>
    )
  }

  const updateStudentEvaluation = (studentId, evaluation) => {
    setStudents(prev => prev.map(student => {
      if (student.id === studentId) {
        const avgPoints = (evaluation.participationPoints + evaluation.behaviorPoints + evaluation.homeworkPoints) / 3
        let status = 'normal'
        if (avgPoints >= 80) status = 'excellent'
        else if (avgPoints < 50) status = 'poor'
        
        return {
          ...student,
          ...evaluation,
          status
        }
      }
      return student
    }))
  }

  const addStudent = (student) => {
    setStudents(prev => [...prev, student])
  }

  const deleteStudent = (studentId) => {
    if (confirm('هل أنت متأكد من حذف هذا التلميذ؟')) {
      setStudents(prev => prev.filter(student => student.id !== studentId))
    }
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">إدارة التلاميذ</h1>
          <p className="text-gray-600 mt-2">إدارة شاملة لبيانات وتقييمات التلاميذ</p>
        </div>
        <div className="flex space-x-4 space-x-reverse">
          <Button onClick={() => setShowAddStudent(true)}>
            <UserPlus className="h-4 w-4 ml-2" />
            إضافة تلميذ
          </Button>
          <div className="relative">
            <input
              type="file"
              accept=".xlsx,.xls"
              onChange={handleFileUpload}
              className="absolute inset-0 opacity-0 cursor-pointer z-10"
              id="excel-upload"
            />
            <label
              htmlFor="excel-upload"
              className="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*=\'size-\')]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50 h-9 px-4 py-2 has-[>svg]:px-3 cursor-pointer"
            >
              <Upload className="h-4 w-4 ml-2" />
              رفع ملف Excel
            </label>
          </div>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label>البحث</Label>
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="ابحث بالاسم أو رقم الهوية"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
              </div>
            </div>
            <div>
              <Label>القسم</Label>
              <select
                className="w-full p-2 border rounded-md"
                value={selectedSection}
                onChange={(e) => setSelectedSection(e.target.value)}
              >
                <option value="all">جميع الأقسام</option>
                {sections.map(section => (
                  <option key={section} value={section}>{section}</option>
                ))}
              </select>
            </div>
            <div>
              <Label>الحالة</Label>
              <select
                className="w-full p-2 border rounded-md"
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
              >
                <option value="all">جميع الحالات</option>
                <option value="excellent">متفوق</option>
                <option value="normal">عادي</option>
                <option value="poor">يحتاج تحسين</option>
              </select>
            </div>
            <div className="flex items-end">
              <Button variant="outline" className="w-full">
                <Download className="h-4 w-4 ml-2" />
                تصدير البيانات
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Students List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredStudents.map(student => (
          <Card key={student.id} className={`border-r-4 ${
            student.status === 'excellent' ? 'border-r-green-500' :
            student.status === 'poor' ? 'border-r-red-500' : 'border-r-blue-500'
          }`}>
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="font-semibold text-lg">{student.name}</h3>
                  <p className="text-sm text-gray-600">{student.section}</p>
                  <p className="text-xs text-gray-500">رقم الهوية: {student.idNumber}</p>
                </div>
                <Badge className={getStatusColor(student.status)}>
                  {getStatusText(student.status)}
                </Badge>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex justify-between text-sm">
                  <span>المشاركة:</span>
                  <span className="font-medium">{student.participationPoints}%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>السلوك:</span>
                  <span className="font-medium">{student.behaviorPoints}%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>الواجبات:</span>
                  <span className="font-medium">{student.homeworkPoints}%</span>
                </div>
              </div>

              <div className="flex justify-between items-center mb-3">
                <div className="flex">
                  {renderStars(student.starRating)}
                </div>
                <span className="text-sm text-gray-600">{student.starRating}/5</span>
              </div>

              {student.badges.length > 0 && (
                <div className="flex flex-wrap gap-1 mb-3">
                  {student.badges.map(badge => (
                    <Badge key={badge} variant="secondary" className="text-xs">
                      {badge}
                    </Badge>
                  ))}
                </div>
              )}

              <div className="flex justify-between">
                <Button
                  size="sm"
                  onClick={() => {
                    setSelectedStudent(student)
                    setShowEvaluation(true)
                  }}
                >
                  <Edit className="h-3 w-3 ml-1" />
                  تقييم
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => deleteStudent(student.id)}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="h-3 w-3 ml-1" />
                  حذف
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredStudents.length === 0 && (
        <div className="text-center py-12">
          <Users className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد نتائج</h3>
          <p className="text-gray-600">لم يتم العثور على تلاميذ يطابقون معايير البحث</p>
        </div>
      )}

      {/* Modals */}
      {showAddStudent && (
        <AddStudentModal
          onClose={() => setShowAddStudent(false)}
          onSave={addStudent}
        />
      )}

      {showEvaluation && selectedStudent && (
        <StudentEvaluationModal
          student={selectedStudent}
          onClose={() => {
            setShowEvaluation(false)
            setSelectedStudent(null)
          }}
          onSave={updateStudentEvaluation}
        />
      )}
    </div>
  )
}

export default StudentsManagement

