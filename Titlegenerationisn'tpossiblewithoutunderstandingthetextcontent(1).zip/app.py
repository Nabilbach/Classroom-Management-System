from flask import Flask, request, send_file
from flask_cors import CORS
from generate_certificate import generate_certificate
import os

app = Flask(__name__)
CORS(app)

@app.route("/generate-certificate", methods=["POST"])
def generate_certificate_route():
    data = request.json
    student_name = data.get("student_name")
    badge_name = data.get("badge_name")
    date_awarded = data.get("date_awarded")

    if not all([student_name, badge_name, date_awarded]):
        return {"error": "Missing data"}, 400

    output_path = f"./certificates/{student_name}_{badge_name}.pdf"
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    generate_certificate(student_name, badge_name, date_awarded, output_path)

    return send_file(output_path, as_attachment=True, download_name=f"{student_name}_{badge_name}.pdf")

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)


