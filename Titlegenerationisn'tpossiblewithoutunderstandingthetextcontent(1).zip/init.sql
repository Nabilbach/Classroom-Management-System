-- إعداد قاعدة البيانات الأولية - نظام إدارة الفصل الدراسي
-- Database Initialization Script

-- إنشاء جدول المستخدمين
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role TEXT CHECK(role IN ('admin', 'teacher', 'assistant')) DEFAULT 'teacher',
    is_active BOOLEAN DEFAULT TRUE,
    two_factor_enabled BOOLEAN DEFAULT FALSE,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- إنشاء جدول الأقسام
CREATE TABLE IF NOT EXISTS sections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(100) NOT NULL,
    grade_level VARCHAR(50) NOT NULL,
    academic_year VARCHAR(20) NOT NULL,
    teacher_id INTEGER,
    classroom VARCHAR(50),
    capacity INTEGER DEFAULT 30,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (teacher_id) REFERENCES users(id)
);

-- إنشاء جدول التلاميذ
CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id VARCHAR(20) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    date_of_birth DATE,
    gender TEXT CHECK(gender IN ('male', 'female')),
    section_id INTEGER,
    parent_name VARCHAR(100),
    parent_phone VARCHAR(20),
    parent_email VARCHAR(100),
    address TEXT,
    enrollment_date DATE DEFAULT CURRENT_DATE,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (section_id) REFERENCES sections(id)
);

-- إنشاء جدول التقييمات
CREATE TABLE IF NOT EXISTS evaluations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    teacher_id INTEGER NOT NULL,
    evaluation_type TEXT CHECK(evaluation_type IN ('academic', 'behavioral', 'participation')) NOT NULL,
    score INTEGER CHECK (score >= 0 AND score <= 100),
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    subject VARCHAR(50),
    notes TEXT,
    evaluation_date DATE DEFAULT CURRENT_DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (teacher_id) REFERENCES users(id)
);

-- إنشاء جدول الحصص
CREATE TABLE IF NOT EXISTS classes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    section_id INTEGER NOT NULL,
    subject VARCHAR(100) NOT NULL,
    teacher_id INTEGER NOT NULL,
    day_of_week INTEGER CHECK (day_of_week >= 1 AND day_of_week <= 7),
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    classroom VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (section_id) REFERENCES sections(id),
    FOREIGN KEY (teacher_id) REFERENCES users(id)
);

-- إنشاء جدول السلوك
CREATE TABLE IF NOT EXISTS behavior_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    teacher_id INTEGER NOT NULL,
    behavior_type TEXT CHECK(behavior_type IN ('positive', 'negative', 'neutral')) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    points INTEGER DEFAULT 0,
    incident_date DATE DEFAULT CURRENT_DATE,
    action_taken TEXT,
    parent_notified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (teacher_id) REFERENCES users(id)
);

-- إنشاء جدول الإنجازات
CREATE TABLE IF NOT EXISTS achievements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    category VARCHAR(50),
    points INTEGER DEFAULT 0,
    badge_icon VARCHAR(50),
    achieved_date DATE DEFAULT CURRENT_DATE,
    awarded_by INTEGER NOT NULL,
    is_visible BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (awarded_by) REFERENCES users(id)
);

-- إنشاء جدول الإشعارات
CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type TEXT CHECK(type IN ('info', 'warning', 'success', 'error')) DEFAULT 'info',
    priority TEXT CHECK(priority IN ('low', 'medium', 'high', 'urgent')) DEFAULT 'medium',
    is_read BOOLEAN DEFAULT FALSE,
    action_url VARCHAR(255),
    expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- إنشاء جدول إعدادات النظام
CREATE TABLE IF NOT EXISTS system_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type TEXT CHECK(setting_type IN ('string', 'integer', 'boolean', 'json')) DEFAULT 'string',
    description TEXT,
    is_public BOOLEAN DEFAULT FALSE,
    updated_by INTEGER,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (updated_by) REFERENCES users(id)
);

-- إنشاء الفهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_students_section ON students(section_id);
CREATE INDEX IF NOT EXISTS idx_evaluations_student ON evaluations(student_id);
CREATE INDEX IF NOT EXISTS idx_evaluations_date ON evaluations(evaluation_date);
CREATE INDEX IF NOT EXISTS idx_behavior_student ON behavior_records(student_id);
CREATE INDEX IF NOT EXISTS idx_behavior_date ON behavior_records(incident_date);
CREATE INDEX IF NOT EXISTS idx_classes_section ON classes(section_id);
CREATE INDEX IF NOT EXISTS idx_classes_teacher ON classes(teacher_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);

-- إدراج بيانات تجريبية

-- إدراج مستخدم مدير افتراضي
INSERT OR IGNORE INTO users (username, email, password_hash, full_name, role) VALUES 
('admin', 'admin@school.edu', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAg/9qK', 'مدير النظام', 'admin');

-- إدراج مدرسين
INSERT OR IGNORE INTO users (username, email, password_hash, full_name, role) VALUES 
('teacher1', 'teacher1@school.edu', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAg/9qK', 'أحمد محمد أحمد', 'teacher'),
('teacher2', 'teacher2@school.edu', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAg/9qK', 'فاطمة علي حسن', 'teacher'),
('teacher3', 'teacher3@school.edu', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAg/9qK', 'عبدالله سالم محمد', 'teacher');

-- إدراج الأقسام
INSERT OR IGNORE INTO sections (name, grade_level, academic_year, teacher_id, classroom, capacity) VALUES 
('الصف الأول', 'الصف الأول ابتدائي - التربية الإسلامية', '2024-2025', 2, 'الأحد', 30),
('الصف الثاني', 'الصف ثاني ابتدائي - التربية الإسلامية', '2024-2025', 2, 'الثلاثاء', 28),
('الصف الثالث', 'الصف ثالث ابتدائي - التربية الإسلامية', '2024-2025', 2, 'الأحد', 32),
('الصف الرابع', 'الصف رابع ابتدائي - التربية الإسلامية', '2024-2025', 3, 'الثلاثاء', 29),
('الصف الخامس', 'الصف خامس ابتدائي - التربية الإسلامية', '2024-2025', 3, 'الأحد', 31),
('الصف السادس', 'الصف سادس ابتدائي - التربية الإسلامية', '2024-2025', 3, 'الثلاثاء', 30);

-- إدراج التلاميذ
INSERT OR IGNORE INTO students (student_id, first_name, last_name, date_of_birth, gender, section_id, parent_name, parent_phone) VALUES 
-- الصف الأول
('S001', 'محمد', 'أحمد', '2017-05-15', 'male', 1, 'أحمد محمد علي', '0501234567'),
('S002', 'فاطمة', 'أحمد حسن', '2017-03-22', 'female', 1, 'أحمد حسن محمد', '0507654321'),
('S003', 'عبدالله', 'سالم', '2017-07-10', 'male', 1, 'سالم عبدالله أحمد', '0509876543'),
('S004', 'عائشة', 'محمد', '2017-01-18', 'female', 1, 'محمد عبدالرحمن', '0502468135'),
('S005', 'يوسف', 'علي', '2017-09-05', 'male', 1, 'علي يوسف محمد', '0508642097'),

-- الصف الثاني
('S006', 'خديجة', 'أحمد', '2016-04-12', 'female', 2, 'أحمد محمد سالم', '0503691472'),
('S007', 'عمر', 'عبدالله', '2016-06-28', 'male', 2, 'عبدالله عمر أحمد', '0505827394'),
('S008', 'زينب', 'محمد', '2016-02-14', 'female', 2, 'محمد أحمد علي', '0507418529'),
('S009', 'حسن', 'علي', '2016-08-30', 'male', 2, 'علي حسن محمد', '0509630741'),
('S010', 'مريم', 'سالم', '2016-11-07', 'female', 2, 'سالم أحمد عبدالله', '0502574836'),

-- الصف الثالث
('S011', 'أحمد', 'محمد علي', '2015-03-20', 'male', 3, 'محمد علي أحمد', '0508529637'),
('S012', 'نور', 'عبدالله', '2015-05-16', 'female', 3, 'عبدالله محمد سالم', '0504173958'),
('S013', 'سارة', 'أحمد', '2015-07-25', 'female', 3, 'أحمد سالم محمد', '0506285174'),
('S014', 'محمود', 'علي', '2015-01-11', 'male', 3, 'علي محمود أحمد', '0509417263'),
('S015', 'هدى', 'محمد', '2015-09-08', 'female', 3, 'محمد أحمد عبدالله', '0503748592'),

-- الصف الرابع
('S016', 'عائشة', 'محمد', '2014-04-18', 'female', 4, 'محمد عبدالرحمن علي', '0507395184'),
('S017', 'خالد', 'أحمد', '2014-06-22', 'male', 4, 'أحمد خالد محمد', '0505162738'),
('S018', 'ليلى', 'سالم', '2014-02-09', 'female', 4, 'سالم محمد أحمد', '0508741629'),
('S019', 'عبدالرحمن', 'علي', '2014-08-14', 'male', 4, 'علي عبدالرحمن محمد', '0502639517'),
('S020', 'أسماء', 'محمد', '2014-10-27', 'female', 4, 'محمد أحمد سالم', '0509528374'),

-- الصف الخامس
('S021', 'أحمد', 'حسن', '2013-03-15', 'male', 5, 'حسن أحمد محمد', '0504817263'),
('S022', 'رقية', 'عبدالله', '2013-05-20', 'female', 5, 'عبدالله محمد علي', '0507294851'),
('S023', 'يوسف', 'سالم', '2013-07-12', 'male', 5, 'سالم يوسف أحمد', '0503658174'),
('S024', 'حفصة', 'محمد', '2013-01-28', 'female', 5, 'محمد علي عبدالله', '0508417392'),
('S025', 'عثمان', 'أحمد', '2013-09-06', 'male', 5, 'أحمد عثمان محمد', '0506273948'),

-- الصف السادس
('S026', 'مريم', 'أحمد', '2012-04-10', 'female', 6, 'أحمد محمد حسن', '0509184726'),
('S027', 'عبدالله', 'علي', '2012-06-18', 'male', 6, 'علي عبدالله محمد', '0502847193'),
('S028', 'خديجة', 'سالم', '2012-02-25', 'female', 6, 'سالم أحمد علي', '0507639284'),
('S029', 'محمد', 'حسن', '2012-08-13', 'male', 6, 'حسن محمد أحمد', '0504528173'),
('S030', 'فاطمة', 'عبدالله', '2012-10-30', 'female', 6, 'عبدالله فاطمة محمد', '0508372946');

-- إدراج تقييمات تجريبية
INSERT OR IGNORE INTO evaluations (student_id, teacher_id, evaluation_type, score, rating, subject) VALUES 
-- تقييمات أكاديمية
(1, 2, 'academic', 85, 4, 'التربية الإسلامية'),
(2, 2, 'academic', 92, 5, 'التربية الإسلامية'),
(3, 2, 'academic', 78, 4, 'التربية الإسلامية'),
(4, 2, 'academic', 88, 4, 'التربية الإسلامية'),
(5, 2, 'academic', 95, 5, 'التربية الإسلامية'),

-- تقييمات سلوكية
(1, 2, 'behavioral', 90, 5, NULL),
(2, 2, 'behavioral', 85, 4, NULL),
(3, 2, 'behavioral', 75, 3, NULL),
(4, 2, 'behavioral', 88, 4, NULL),
(5, 2, 'behavioral', 92, 5, NULL);

-- إدراج سجلات سلوك تجريبية
INSERT OR IGNORE INTO behavior_records (student_id, teacher_id, behavior_type, category, description, points) VALUES 
(1, 2, 'positive', 'مشاركة', 'مشاركة ممتازة في الدرس', 5),
(2, 2, 'positive', 'انضباط', 'حضور منتظم ومواظبة', 3),
(3, 2, 'negative', 'سلوك', 'تأخر عن الحصة', -2),
(4, 2, 'positive', 'أداء', 'أداء واجبات ممتاز', 4),
(5, 2, 'positive', 'تفوق', 'حصول على أعلى درجة', 10);

-- إدراج إنجازات تجريبية
INSERT OR IGNORE INTO achievements (student_id, title, description, category, points, badge_icon, awarded_by) VALUES 
(2, 'الطالب المثالي', 'حصل على أعلى التقييمات هذا الشهر', 'أكاديمي', 50, 'star', 2),
(5, 'المشارك النشط', 'أكثر مشاركة في الأنشطة الصفية', 'مشاركة', 30, 'trophy', 2),
(1, 'المواظب', 'حضور منتظم لمدة شهر كامل', 'انضباط', 20, 'calendar', 2);

-- إدراج جدول حصص تجريبي
INSERT OR IGNORE INTO classes (section_id, subject, teacher_id, day_of_week, start_time, end_time, classroom) VALUES 
-- الأحد
(1, 'التربية الإسلامية', 2, 1, '08:00', '08:45', 'A101'),
(3, 'التربية الإسلامية', 2, 1, '09:00', '09:45', 'A103'),
(5, 'التربية الإسلامية', 3, 1, '10:00', '10:45', 'A105'),

-- الاثنين
(2, 'التربية الإسلامية', 2, 2, '08:00', '08:45', 'A102'),
(4, 'التربية الإسلامية', 3, 2, '09:00', '09:45', 'A104'),
(6, 'التربية الإسلامية', 3, 2, '10:00', '10:45', 'A106'),

-- الثلاثاء
(1, 'التربية الإسلامية', 2, 3, '08:00', '08:45', 'A101'),
(3, 'التربية الإسلامية', 2, 3, '09:00', '09:45', 'A103'),
(5, 'التربية الإسلامية', 3, 3, '10:00', '10:45', 'A105'),

-- الأربعاء
(2, 'التربية الإسلامية', 2, 4, '08:00', '08:45', 'A102'),
(4, 'التربية الإسلامية', 3, 4, '09:00', '09:45', 'A104'),
(6, 'التربية الإسلامية', 3, 4, '10:00', '10:45', 'A106'),

-- الخميس
(1, 'التربية الإسلامية', 2, 5, '08:00', '08:45', 'A101'),
(3, 'التربية الإسلامية', 2, 5, '09:00', '09:45', 'A103'),
(5, 'التربية الإسلامية', 3, 5, '10:00', '10:45', 'A105');

-- إدراج إعدادات النظام الافتراضية
INSERT OR IGNORE INTO system_settings (setting_key, setting_value, setting_type, description, is_public) VALUES 
('school_name', 'مدرسة النور الابتدائية', 'string', 'اسم المدرسة', TRUE),
('academic_year', '2024-2025', 'string', 'العام الدراسي الحالي', TRUE),
('max_students_per_section', '35', 'integer', 'الحد الأقصى للتلاميذ في القسم', FALSE),
('backup_frequency', 'daily', 'string', 'تكرار النسخ الاحتياطي', FALSE),
('email_notifications', 'true', 'boolean', 'تفعيل إشعارات البريد الإلكتروني', FALSE),
('session_timeout', '30', 'integer', 'انتهاء الجلسة بالدقائق', FALSE),
('theme', 'light', 'string', 'مظهر النظام', TRUE),
('language', 'ar', 'string', 'لغة النظام', TRUE);

-- إدراج إشعارات تجريبية
INSERT OR IGNORE INTO notifications (user_id, title, message, type, priority) VALUES 
(1, 'مرحباً بك في النظام', 'تم تسجيل دخولك بنجاح إلى نظام إدارة الفصل الدراسي', 'success', 'low'),
(2, 'تقييم جديد', 'تم إضافة تقييم جديد للطالب محمد أحمد', 'info', 'medium'),
(2, 'تنبيه سلوكي', 'الطالب عبدالله سالم يحتاج إلى متابعة سلوكية', 'warning', 'high'),
(3, 'جدول محدث', 'تم تحديث جدول الصف الرابع', 'info', 'medium');

-- إنشاء views مفيدة للتقارير
CREATE VIEW IF NOT EXISTS student_summary AS
SELECT 
    s.id,
    s.student_id,
    s.first_name || ' ' || s.last_name AS full_name,
    sec.name AS section_name,
    sec.grade_level,
    COALESCE(AVG(e.score), 0) AS avg_academic_score,
    COALESCE(AVG(CASE WHEN e.evaluation_type = 'behavioral' THEN e.rating END), 0) AS avg_behavioral_rating,
    COALESCE(SUM(br.points), 0) AS total_behavior_points,
    COUNT(a.id) AS total_achievements
FROM students s
LEFT JOIN sections sec ON s.section_id = sec.id
LEFT JOIN evaluations e ON s.id = e.student_id
LEFT JOIN behavior_records br ON s.id = br.student_id
LEFT JOIN achievements a ON s.id = a.student_id
WHERE s.is_active = TRUE
GROUP BY s.id;

CREATE VIEW IF NOT EXISTS section_statistics AS
SELECT 
    s.id,
    s.name,
    s.grade_level,
    COUNT(st.id) AS total_students,
    COALESCE(AVG(e.score), 0) AS avg_academic_score,
    COALESCE(AVG(CASE WHEN e.evaluation_type = 'behavioral' THEN e.rating END), 0) AS avg_behavioral_rating,
    COUNT(CASE WHEN br.behavior_type = 'positive' THEN 1 END) AS positive_behaviors,
    COUNT(CASE WHEN br.behavior_type = 'negative' THEN 1 END) AS negative_behaviors
FROM sections s
LEFT JOIN students st ON s.id = st.section_id AND st.is_active = TRUE
LEFT JOIN evaluations e ON st.id = e.student_id
LEFT JOIN behavior_records br ON st.id = br.student_id
WHERE s.is_active = TRUE
GROUP BY s.id;

