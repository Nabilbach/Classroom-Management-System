import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { 
  BookOpen, 
  Plus, 
  Edit, 
  Trash2,
  Users,
  Award,
  AlertTriangle,
  TrendingUp,
  Calendar,
  Clock,
  Target
} from 'lucide-react'

const SectionsManagement = () => {
  const [sections, setSections] = useState([
    {
      id: 1,
      name: 'الصف الأول',
      description: 'صف أول ابتدائي - التربية الإسلامية',
      totalStudents: 30,
      excellentStudents: 8,
      behaviorIssues: 1,
      averageGrade: 85,
      teacher: 'الأستاذ محمد أحمد',
      schedule: [
        { day: 'الأحد', time: '08:00 - 09:00' },
        { day: 'الثلاثاء', time: '10:00 - 11:00' },
        { day: 'الخميس', time: '09:00 - 10:00' }
      ],
      createdAt: '2024-01-15'
    },
    {
      id: 2,
      name: 'الصف الثاني',
      description: 'صف ثاني ابتدائي - التربية الإسلامية',
      totalStudents: 28,
      excellentStudents: 7,
      behaviorIssues: 2,
      averageGrade: 78,
      teacher: 'الأستاذة فاطمة علي',
      schedule: [
        { day: 'الأحد', time: '09:00 - 10:00' },
        { day: 'الثلاثاء', time: '11:00 - 12:00' },
        { day: 'الخميس', time: '08:00 - 09:00' }
      ],
      createdAt: '2024-01-15'
    },
    {
      id: 3,
      name: 'الصف الثالث',
      description: 'صف ثالث ابتدائي - التربية الإسلامية',
      totalStudents: 32,
      excellentStudents: 9,
      behaviorIssues: 1,
      averageGrade: 88,
      teacher: 'الأستاذ عبدالله سالم',
      schedule: [
        { day: 'الأحد', time: '10:00 - 11:00' },
        { day: 'الثلاثاء', time: '08:00 - 09:00' },
        { day: 'الخميس', time: '11:00 - 12:00' }
      ],
      createdAt: '2024-01-15'
    },
    {
      id: 4,
      name: 'الصف الرابع',
      description: 'صف رابع ابتدائي - التربية الإسلامية',
      totalStudents: 29,
      excellentStudents: 6,
      behaviorIssues: 2,
      averageGrade: 75,
      teacher: 'الأستاذة عائشة محمد',
      schedule: [
        { day: 'الأحد', time: '11:00 - 12:00' },
        { day: 'الثلاثاء', time: '09:00 - 10:00' },
        { day: 'الخميس', time: '10:00 - 11:00' }
      ],
      createdAt: '2024-01-15'
    },
    {
      id: 5,
      name: 'الصف الخامس',
      description: 'صف خامس ابتدائي - التربية الإسلامية',
      totalStudents: 31,
      excellentStudents: 8,
      behaviorIssues: 1,
      averageGrade: 82,
      teacher: 'الأستاذ أحمد حسن',
      schedule: [
        { day: 'الأحد', time: '12:00 - 13:00' },
        { day: 'الثلاثاء', time: '12:00 - 13:00' },
        { day: 'الخميس', time: '12:00 - 13:00' }
      ],
      createdAt: '2024-01-15'
    },
    {
      id: 6,
      name: 'الصف السادس',
      description: 'صف سادس ابتدائي - التربية الإسلامية',
      totalStudents: 30,
      excellentStudents: 7,
      behaviorIssues: 1,
      averageGrade: 80,
      teacher: 'الأستاذة مريم أحمد',
      schedule: [
        { day: 'الأحد', time: '13:00 - 14:00' },
        { day: 'الثلاثاء', time: '13:00 - 14:00' },
        { day: 'الخميس', time: '13:00 - 14:00' }
      ],
      createdAt: '2024-01-15'
    }
  ])

  const [showAddSection, setShowAddSection] = useState(false)
  const [selectedSection, setSelectedSection] = useState(null)
  const [showEditSection, setShowEditSection] = useState(false)
  const [showSectionDetails, setShowSectionDetails] = useState(false)

  const getPerformanceColor = (grade) => {
    if (grade >= 85) return 'text-green-600'
    if (grade >= 70) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getPerformanceText = (grade) => {
    if (grade >= 85) return 'ممتاز'
    if (grade >= 70) return 'جيد'
    return 'يحتاج تحسين'
  }

  const AddSectionModal = ({ onClose, onSave }) => {
    const [newSection, setNewSection] = useState({
      name: '',
      description: '',
      teacher: '',
      schedule: [
        { day: '', time: '' }
      ]
    })

    const handleSave = () => {
      if (newSection.name && newSection.description && newSection.teacher) {
        const section = {
          ...newSection,
          id: Date.now(),
          totalStudents: 0,
          excellentStudents: 0,
          behaviorIssues: 0,
          averageGrade: 0,
          createdAt: new Date().toISOString().split('T')[0]
        }
        onSave(section)
        onClose()
      }
    }

    const addScheduleSlot = () => {
      setNewSection(prev => ({
        ...prev,
        schedule: [...prev.schedule, { day: '', time: '' }]
      }))
    }

    const updateScheduleSlot = (index, field, value) => {
      setNewSection(prev => ({
        ...prev,
        schedule: prev.schedule.map((slot, i) => 
          i === index ? { ...slot, [field]: value } : slot
        )
      }))
    }

    const removeScheduleSlot = (index) => {
      setNewSection(prev => ({
        ...prev,
        schedule: prev.schedule.filter((_, i) => i !== index)
      }))
    }

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" dir="rtl">
        <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">إضافة قسم جديد</h2>
            <Button variant="outline" onClick={onClose}>إغلاق</Button>
          </div>

          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>اسم القسم</Label>
                <Input
                  value={newSection.name}
                  onChange={(e) => setNewSection(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="مثال: الصف السابع"
                />
              </div>
              <div>
                <Label>المعلم المسؤول</Label>
                <Input
                  value={newSection.teacher}
                  onChange={(e) => setNewSection(prev => ({ ...prev, teacher: e.target.value }))}
                  placeholder="اسم المعلم"
                />
              </div>
            </div>

            <div>
              <Label>وصف القسم</Label>
              <Input
                value={newSection.description}
                onChange={(e) => setNewSection(prev => ({ ...prev, description: e.target.value }))}
                placeholder="وصف مختصر للقسم"
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-4">
                <Label>الجدول الزمني</Label>
                <Button size="sm" onClick={addScheduleSlot}>
                  <Plus className="h-4 w-4 ml-1" />
                  إضافة حصة
                </Button>
              </div>
              
              {newSection.schedule.map((slot, index) => (
                <div key={index} className="flex gap-4 items-center mb-2">
                  <select
                    className="flex-1 p-2 border rounded-md"
                    value={slot.day}
                    onChange={(e) => updateScheduleSlot(index, 'day', e.target.value)}
                  >
                    <option value="">اختر اليوم</option>
                    <option value="الأحد">الأحد</option>
                    <option value="الاثنين">الاثنين</option>
                    <option value="الثلاثاء">الثلاثاء</option>
                    <option value="الأربعاء">الأربعاء</option>
                    <option value="الخميس">الخميس</option>
                  </select>
                  <Input
                    className="flex-1"
                    value={slot.time}
                    onChange={(e) => updateScheduleSlot(index, 'time', e.target.value)}
                    placeholder="مثال: 08:00 - 09:00"
                  />
                  {newSection.schedule.length > 1 && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => removeScheduleSlot(index)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            <div className="flex justify-end space-x-4 space-x-reverse">
              <Button variant="outline" onClick={onClose}>إلغاء</Button>
              <Button onClick={handleSave}>إضافة القسم</Button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const SectionDetailsModal = ({ section, onClose }) => {
    if (!section) return null

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" dir="rtl">
        <div className="bg-white rounded-lg p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">تفاصيل {section.name}</h2>
            <Button variant="outline" onClick={onClose}>إغلاق</Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">إجمالي التلاميذ</p>
                    <p className="text-2xl font-bold">{section.totalStudents}</p>
                  </div>
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">المتفوقون</p>
                    <p className="text-2xl font-bold text-green-600">{section.excellentStudents}</p>
                  </div>
                  <Award className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">مشاكل سلوكية</p>
                    <p className="text-2xl font-bold text-red-600">{section.behaviorIssues}</p>
                  </div>
                  <AlertTriangle className="h-8 w-8 text-red-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">المعدل العام</p>
                    <p className={`text-2xl font-bold ${getPerformanceColor(section.averageGrade)}`}>
                      {section.averageGrade}%
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>معلومات القسم</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <Label className="text-sm font-medium text-gray-600">اسم القسم</Label>
                    <p className="font-medium">{section.name}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-600">الوصف</Label>
                    <p className="text-gray-700">{section.description}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-600">المعلم المسؤول</Label>
                    <p className="font-medium">{section.teacher}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-600">تاريخ الإنشاء</Label>
                    <p className="text-gray-700">{section.createdAt}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-600">الأداء العام</Label>
                    <Badge className={`${
                      section.averageGrade >= 85 ? 'bg-green-100 text-green-800' :
                      section.averageGrade >= 70 ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {getPerformanceText(section.averageGrade)}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>الجدول الزمني</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {section.schedule.map((slot, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3 space-x-reverse">
                        <Calendar className="h-4 w-4 text-blue-600" />
                        <span className="font-medium">{slot.day}</span>
                      </div>
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <Clock className="h-4 w-4 text-gray-500" />
                        <span className="text-gray-700">{slot.time}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  const addSection = (section) => {
    setSections(prev => [...prev, section])
  }

  const deleteSection = (sectionId) => {
    if (confirm('هل أنت متأكد من حذف هذا القسم؟ سيتم حذف جميع البيانات المرتبطة به.')) {
      setSections(prev => prev.filter(section => section.id !== sectionId))
    }
  }

  const totalStudents = sections.reduce((sum, section) => sum + section.totalStudents, 0)
  const totalExcellent = sections.reduce((sum, section) => sum + section.excellentStudents, 0)
  const totalIssues = sections.reduce((sum, section) => sum + section.behaviorIssues, 0)
  const averagePerformance = sections.length > 0 
    ? Math.round(sections.reduce((sum, section) => sum + section.averageGrade, 0) / sections.length)
    : 0

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">إدارة الأقسام</h1>
          <p className="text-gray-600 mt-2">إدارة شاملة للأقسام الدراسية والجداول الزمنية</p>
        </div>
        <Button onClick={() => setShowAddSection(true)}>
          <Plus className="h-4 w-4 ml-2" />
          إضافة قسم جديد
        </Button>
      </div>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-600">إجمالي الأقسام</p>
                <p className="text-2xl font-bold text-blue-900">{sections.length}</p>
              </div>
              <BookOpen className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-600">إجمالي التلاميذ</p>
                <p className="text-2xl font-bold text-green-900">{totalStudents}</p>
              </div>
              <Users className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-yellow-600">المتفوقون</p>
                <p className="text-2xl font-bold text-yellow-900">{totalExcellent}</p>
              </div>
              <Award className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-purple-600">المعدل العام</p>
                <p className="text-2xl font-bold text-purple-900">{averagePerformance}%</p>
              </div>
              <Target className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sections Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sections.map(section => (
          <Card key={section.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg">{section.name}</CardTitle>
                  <CardDescription>{section.description}</CardDescription>
                </div>
                <Badge className={`${
                  section.averageGrade >= 85 ? 'bg-green-100 text-green-800' :
                  section.averageGrade >= 70 ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {getPerformanceText(section.averageGrade)}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">المعلم:</span>
                  <span className="font-medium">{section.teacher}</span>
                </div>
                
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="bg-blue-50 p-2 rounded">
                    <p className="text-xs text-blue-600">التلاميذ</p>
                    <p className="font-bold text-blue-900">{section.totalStudents}</p>
                  </div>
                  <div className="bg-green-50 p-2 rounded">
                    <p className="text-xs text-green-600">متفوقون</p>
                    <p className="font-bold text-green-900">{section.excellentStudents}</p>
                  </div>
                  <div className="bg-red-50 p-2 rounded">
                    <p className="text-xs text-red-600">مشاكل</p>
                    <p className="font-bold text-red-900">{section.behaviorIssues}</p>
                  </div>
                </div>

                <div className="border-t pt-3">
                  <p className="text-xs text-gray-600 mb-2">الجدول الزمني:</p>
                  <div className="space-y-1">
                    {section.schedule.slice(0, 2).map((slot, index) => (
                      <div key={index} className="flex justify-between text-xs">
                        <span>{slot.day}</span>
                        <span className="text-gray-600">{slot.time}</span>
                      </div>
                    ))}
                    {section.schedule.length > 2 && (
                      <p className="text-xs text-gray-500">+{section.schedule.length - 2} حصص أخرى</p>
                    )}
                  </div>
                </div>

                <div className="flex justify-between pt-3 border-t">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setSelectedSection(section)
                      setShowSectionDetails(true)
                    }}
                  >
                    <BookOpen className="h-3 w-3 ml-1" />
                    التفاصيل
                  </Button>
                  <div className="flex space-x-2 space-x-reverse">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setSelectedSection(section)
                        setShowEditSection(true)
                      }}
                    >
                      <Edit className="h-3 w-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => deleteSection(section.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {sections.length === 0 && (
        <div className="text-center py-12">
          <BookOpen className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد أقسام</h3>
          <p className="text-gray-600 mb-4">ابدأ بإضافة قسم جديد لإدارة التلاميذ</p>
          <Button onClick={() => setShowAddSection(true)}>
            <Plus className="h-4 w-4 ml-2" />
            إضافة قسم جديد
          </Button>
        </div>
      )}

      {/* Modals */}
      {showAddSection && (
        <AddSectionModal
          onClose={() => setShowAddSection(false)}
          onSave={addSection}
        />
      )}

      {showSectionDetails && selectedSection && (
        <SectionDetailsModal
          section={selectedSection}
          onClose={() => {
            setShowSectionDetails(false)
            setSelectedSection(null)
          }}
        />
      )}
    </div>
  )
}

export default SectionsManagement

