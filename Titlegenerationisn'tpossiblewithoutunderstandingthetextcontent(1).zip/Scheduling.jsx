import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { 
  Calendar, 
  Clock, 
  Plus, 
  Edit, 
  Trash2,
  BookOpen,
  Users,
  ChevronLeft,
  ChevronRight,
  Filter,
  Download,
  RefreshCw
} from 'lucide-react'

const Scheduling = () => {
  const [currentView, setCurrentView] = useState('week') // week, month
  const [currentDate, setCurrentDate] = useState(new Date())
  const [showAddSession, setShowAddSession] = useState(false)
  const [selectedTimeSlot, setSelectedTimeSlot] = useState(null)

  // Sample schedule data
  const [schedule, setSchedule] = useState([
    {
      id: 1,
      section: 'الصف الأول',
      teacher: 'الأستاذ محمد أحمد',
      day: 'الأحد',
      startTime: '08:00',
      endTime: '09:00',
      subject: 'التربية الإسلامية',
      room: 'قاعة 101',
      students: 30,
      color: 'bg-blue-100 text-blue-800 border-blue-200'
    },
    {
      id: 2,
      section: 'الصف الثاني',
      teacher: 'الأستاذة فاطمة علي',
      day: 'الأحد',
      startTime: '09:00',
      endTime: '10:00',
      subject: 'التربية الإسلامية',
      room: 'قاعة 102',
      students: 28,
      color: 'bg-green-100 text-green-800 border-green-200'
    },
    {
      id: 3,
      section: 'الصف الثالث',
      teacher: 'الأستاذ عبدالله سالم',
      day: 'الأحد',
      startTime: '10:00',
      endTime: '11:00',
      subject: 'التربية الإسلامية',
      room: 'قاعة 103',
      students: 32,
      color: 'bg-yellow-100 text-yellow-800 border-yellow-200'
    },
    {
      id: 4,
      section: 'الصف الرابع',
      teacher: 'الأستاذة عائشة محمد',
      day: 'الأحد',
      startTime: '11:00',
      endTime: '12:00',
      subject: 'التربية الإسلامية',
      room: 'قاعة 104',
      students: 29,
      color: 'bg-purple-100 text-purple-800 border-purple-200'
    },
    {
      id: 5,
      section: 'الصف الخامس',
      teacher: 'الأستاذ أحمد حسن',
      day: 'الأحد',
      startTime: '12:00',
      endTime: '13:00',
      subject: 'التربية الإسلامية',
      room: 'قاعة 105',
      students: 31,
      color: 'bg-red-100 text-red-800 border-red-200'
    },
    {
      id: 6,
      section: 'الصف السادس',
      teacher: 'الأستاذة مريم أحمد',
      day: 'الأحد',
      startTime: '13:00',
      endTime: '14:00',
      subject: 'التربية الإسلامية',
      room: 'قاعة 106',
      students: 30,
      color: 'bg-indigo-100 text-indigo-800 border-indigo-200'
    },
    // Tuesday sessions
    {
      id: 7,
      section: 'الصف الأول',
      teacher: 'الأستاذ محمد أحمد',
      day: 'الثلاثاء',
      startTime: '10:00',
      endTime: '11:00',
      subject: 'التربية الإسلامية',
      room: 'قاعة 101',
      students: 30,
      color: 'bg-blue-100 text-blue-800 border-blue-200'
    },
    {
      id: 8,
      section: 'الصف الثاني',
      teacher: 'الأستاذة فاطمة علي',
      day: 'الثلاثاء',
      startTime: '11:00',
      endTime: '12:00',
      subject: 'التربية الإسلامية',
      room: 'قاعة 102',
      students: 28,
      color: 'bg-green-100 text-green-800 border-green-200'
    },
    // Thursday sessions
    {
      id: 9,
      section: 'الصف الثالث',
      teacher: 'الأستاذ عبدالله سالم',
      day: 'الخميس',
      startTime: '11:00',
      endTime: '12:00',
      subject: 'التربية الإسلامية',
      room: 'قاعة 103',
      students: 32,
      color: 'bg-yellow-100 text-yellow-800 border-yellow-200'
    },
    {
      id: 10,
      section: 'الصف الرابع',
      teacher: 'الأستاذة عائشة محمد',
      day: 'الخميس',
      startTime: '10:00',
      endTime: '11:00',
      subject: 'التربية الإسلامية',
      room: 'قاعة 104',
      students: 29,
      color: 'bg-purple-100 text-purple-800 border-purple-200'
    }
  ])

  const days = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس']
  const timeSlots = [
    '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00'
  ]

  const getSessionsForDayAndTime = (day, time) => {
    return schedule.filter(session => 
      session.day === day && session.startTime === time
    )
  }

  const AddSessionModal = ({ onClose, onSave, timeSlot }) => {
    const [newSession, setNewSession] = useState({
      section: '',
      teacher: '',
      day: timeSlot?.day || '',
      startTime: timeSlot?.time || '',
      endTime: '',
      subject: 'التربية الإسلامية',
      room: '',
      students: 0,
      color: 'bg-blue-100 text-blue-800 border-blue-200'
    })

    const handleSave = () => {
      if (newSession.section && newSession.teacher && newSession.day && 
          newSession.startTime && newSession.endTime && newSession.room) {
        const session = {
          ...newSession,
          id: Date.now(),
          students: parseInt(newSession.students) || 0
        }
        onSave(session)
        onClose()
      }
    }

    const colorOptions = [
      { value: 'bg-blue-100 text-blue-800 border-blue-200', label: 'أزرق' },
      { value: 'bg-green-100 text-green-800 border-green-200', label: 'أخضر' },
      { value: 'bg-yellow-100 text-yellow-800 border-yellow-200', label: 'أصفر' },
      { value: 'bg-purple-100 text-purple-800 border-purple-200', label: 'بنفسجي' },
      { value: 'bg-red-100 text-red-800 border-red-200', label: 'أحمر' },
      { value: 'bg-indigo-100 text-indigo-800 border-indigo-200', label: 'نيلي' }
    ]

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" dir="rtl">
        <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">إضافة حصة جديدة</h2>
            <Button variant="outline" onClick={onClose}>إغلاق</Button>
          </div>

          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>القسم</Label>
                <Input
                  value={newSession.section}
                  onChange={(e) => setNewSession(prev => ({ ...prev, section: e.target.value }))}
                  placeholder="اسم القسم"
                />
              </div>
              <div>
                <Label>المعلم</Label>
                <Input
                  value={newSession.teacher}
                  onChange={(e) => setNewSession(prev => ({ ...prev, teacher: e.target.value }))}
                  placeholder="اسم المعلم"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label>اليوم</Label>
                <select
                  className="w-full p-2 border rounded-md"
                  value={newSession.day}
                  onChange={(e) => setNewSession(prev => ({ ...prev, day: e.target.value }))}
                >
                  <option value="">اختر اليوم</option>
                  {days.map(day => (
                    <option key={day} value={day}>{day}</option>
                  ))}
                </select>
              </div>
              <div>
                <Label>وقت البداية</Label>
                <select
                  className="w-full p-2 border rounded-md"
                  value={newSession.startTime}
                  onChange={(e) => setNewSession(prev => ({ ...prev, startTime: e.target.value }))}
                >
                  <option value="">اختر الوقت</option>
                  {timeSlots.map(time => (
                    <option key={time} value={time}>{time}</option>
                  ))}
                </select>
              </div>
              <div>
                <Label>وقت النهاية</Label>
                <select
                  className="w-full p-2 border rounded-md"
                  value={newSession.endTime}
                  onChange={(e) => setNewSession(prev => ({ ...prev, endTime: e.target.value }))}
                >
                  <option value="">اختر الوقت</option>
                  {timeSlots.map(time => (
                    <option key={time} value={time}>{time}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label>المادة</Label>
                <Input
                  value={newSession.subject}
                  onChange={(e) => setNewSession(prev => ({ ...prev, subject: e.target.value }))}
                  placeholder="اسم المادة"
                />
              </div>
              <div>
                <Label>القاعة</Label>
                <Input
                  value={newSession.room}
                  onChange={(e) => setNewSession(prev => ({ ...prev, room: e.target.value }))}
                  placeholder="رقم القاعة"
                />
              </div>
              <div>
                <Label>عدد التلاميذ</Label>
                <Input
                  type="number"
                  value={newSession.students}
                  onChange={(e) => setNewSession(prev => ({ ...prev, students: e.target.value }))}
                  placeholder="عدد التلاميذ"
                />
              </div>
            </div>

            <div>
              <Label>لون التمييز</Label>
              <select
                className="w-full p-2 border rounded-md"
                value={newSession.color}
                onChange={(e) => setNewSession(prev => ({ ...prev, color: e.target.value }))}
              >
                {colorOptions.map(option => (
                  <option key={option.value} value={option.value}>{option.label}</option>
                ))}
              </select>
            </div>

            <div className="flex justify-end space-x-4 space-x-reverse">
              <Button variant="outline" onClick={onClose}>إلغاء</Button>
              <Button onClick={handleSave}>إضافة الحصة</Button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const WeeklyView = () => (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse border border-gray-300">
        <thead>
          <tr className="bg-gray-50">
            <th className="border border-gray-300 p-3 text-right font-semibold">الوقت</th>
            {days.map(day => (
              <th key={day} className="border border-gray-300 p-3 text-center font-semibold min-w-[200px]">
                {day}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {timeSlots.map(time => (
            <tr key={time} className="hover:bg-gray-50">
              <td className="border border-gray-300 p-3 font-medium bg-gray-50">
                {time}
              </td>
              {days.map(day => {
                const sessions = getSessionsForDayAndTime(day, time)
                return (
                  <td 
                    key={`${day}-${time}`} 
                    className="border border-gray-300 p-2 h-20 cursor-pointer hover:bg-blue-50"
                    onClick={() => {
                      setSelectedTimeSlot({ day, time })
                      setShowAddSession(true)
                    }}
                  >
                    {sessions.length > 0 ? (
                      <div className="space-y-1">
                        {sessions.map(session => (
                          <div
                            key={session.id}
                            className={`p-2 rounded-md border text-xs ${session.color}`}
                          >
                            <div className="font-semibold">{session.section}</div>
                            <div className="text-xs">{session.teacher}</div>
                            <div className="text-xs">{session.room}</div>
                            <div className="flex items-center justify-between mt-1">
                              <span className="text-xs">{session.students} تلميذ</span>
                              <div className="flex space-x-1 space-x-reverse">
                                <button className="text-blue-600 hover:text-blue-800" onClick={() => alert("سيتم تعديل الحصة: " + session.id)}>
                                  <Edit className="h-3 w-3" />
                                </button>
                                <button className="text-red-600 hover:text-red-800" onClick={() => deleteSession(session.id)}>
                                  <Trash2 className="h-3 w-3" />
                                </button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="h-full flex items-center justify-center text-gray-400 text-xs">
                        انقر لإضافة حصة
                      </div>
                    )}
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )

  const addSession = (session) => {
    setSchedule(prev => [...prev, session])
  }

  const deleteSession = (sessionId) => {
    if (confirm('هل أنت متأكد من حذف هذه الحصة؟')) {
      setSchedule(prev => prev.filter(session => session.id !== sessionId))
    }
  }

  const exportSchedule = () => {
    alert('سيتم تصدير الجدول الزمني')
  }

  const refreshSchedule = () => {
    // This would refresh the schedule from the server
    alert('تم تحديث الجدول الزمني')
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">جدولة الحصص</h1>
          <p className="text-gray-600 mt-2">إدارة وتنظيم الجداول الزمنية للحصص الدراسية</p>
        </div>
        <div className="flex space-x-4 space-x-reverse">
          <Button variant="outline" onClick={refreshSchedule}>
            <RefreshCw className="h-4 w-4 ml-2" />
            تحديث
          </Button>
          <Button variant="outline" onClick={exportSchedule}>
            <Download className="h-4 w-4 ml-2" />
            تصدير
          </Button>
          <Button onClick={() => setShowAddSession(true)}>
            <Plus className="h-4 w-4 ml-2" />
            إضافة حصة
          </Button>
        </div>
      </div>

      {/* View Controls */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex space-x-4 space-x-reverse">
              <div className="flex items-center space-x-2 space-x-reverse">
                <Button
                  size="sm"
                  variant={currentView === 'week' ? 'default' : 'outline'}
                  onClick={() => setCurrentView('week')}
                >
                  <Calendar className="h-4 w-4 ml-1" />
                  عرض أسبوعي
                </Button>
                <Button
                  size="sm"
                  variant={currentView === 'month' ? 'default' : 'outline'}
                  onClick={() => setCurrentView('month')}
                >
                  <BookOpen className="h-4 w-4 ml-1" />
                  عرض شهري
                </Button>
              </div>
            </div>

            <div className="flex items-center space-x-4 space-x-reverse">
              <Button size="sm" variant="outline">
                <ChevronRight className="h-4 w-4" />
              </Button>
              <span className="font-medium">
                {currentDate.toLocaleDateString('ar-SA', { 
                  year: 'numeric', 
                  month: 'long' 
                })}
              </span>
              <Button size="sm" variant="outline">
                <ChevronLeft className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Schedule Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-600">إجمالي الحصص</p>
                <p className="text-2xl font-bold text-blue-900">{schedule.length}</p>
              </div>
              <Calendar className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-600">الحصص اليوم</p>
                <p className="text-2xl font-bold text-green-900">
                  {schedule.filter(s => s.day === 'الأحد').length}
                </p>
              </div>
              <Clock className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-yellow-600">المعلمون النشطون</p>
                <p className="text-2xl font-bold text-yellow-900">
                  {new Set(schedule.map(s => s.teacher)).size}
                </p>
              </div>
              <Users className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-purple-600">القاعات المستخدمة</p>
                <p className="text-2xl font-bold text-purple-900">
                  {new Set(schedule.map(s => s.room)).size}
                </p>
              </div>
              <BookOpen className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Schedule View */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Calendar className="h-5 w-5 ml-2" />
            الجدول الزمني الأسبوعي
          </CardTitle>
          <CardDescription>
            انقر على أي خانة فارغة لإضافة حصة جديدة
          </CardDescription>
        </CardHeader>
        <CardContent>
          {currentView === 'week' && <WeeklyView />}
        </CardContent>
      </Card>

      {/* Add Session Modal */}
      {showAddSession && (
        <AddSessionModal
          onClose={() => {
            setShowAddSession(false)
            setSelectedTimeSlot(null)
          }}
          onSave={addSession}
          timeSlot={selectedTimeSlot}
        />
      )}
    </div>
  )
}

export default Scheduling

