import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { 
  Settings, 
  Search, 
  Bell, 
  Shield, 
  Database, 
  Mail, 
  Download, 
  Upload,
  Key,
  Globe,
  Palette,
  Volume2,
  Moon,
  Sun,
  Smartphone,
  Wifi,
  HardDrive,
  Clock,
  Users,
  Lock,
  Eye,
  EyeOff,
  Save,
  RefreshCw,
  AlertTriangle,
  CheckCircle
} from 'lucide-react'

const SettingsComponent = () => {
  const [activeTab, setActiveTab] = useState('general')
  const [settings, setSettings] = useState({
    // General Settings
    language: 'ar',
    theme: 'light',
    notifications: true,
    soundEnabled: true,
    autoSave: true,
    
    // Security Settings
    twoFactorAuth: false,
    sessionTimeout: 30,
    passwordExpiry: 90,
    loginAttempts: 3,
    
    // Backup Settings
    autoBackup: true,
    backupFrequency: 'daily',
    backupLocation: 'cloud',
    
    // Email Settings
    emailNotifications: true,
    emailReports: true,
    emailFrequency: 'weekly',
    smtpServer: '',
    smtpPort: 587,
    smtpUsername: '',
    smtpPassword: '',
    
    // Search Settings
    searchHistory: true,
    searchSuggestions: true,
    indexing: true,
    
    // Privacy Settings
    dataCollection: true,
    analytics: true,
    cookieConsent: true
  })

  const [showPassword, setShowPassword] = useState(false)
  const [backupStatus, setBackupStatus] = useState('success') // success, error, loading

  const handleSettingChange = (key, value) => {
    setSettings(prev => ({ ...prev, [key]: value }))
  }

  const saveSettings = () => {
    // Simulate saving settings
    alert('تم حفظ الإعدادات بنجاح!')
  }

  const performBackup = () => {
    setBackupStatus('loading')
    // Simulate backup process
    setTimeout(() => {
      setBackupStatus('success')
      alert('تم إنشاء النسخة الاحتياطية بنجاح!')
    }, 2000)
  }

  const testEmailConnection = () => {
    alert('تم اختبار الاتصال بالبريد الإلكتروني بنجاح!')
  }

  const tabs = [
    { id: 'general', label: 'عام', icon: Settings },
    { id: 'security', label: 'الأمان', icon: Shield },
    { id: 'backup', label: 'النسخ الاحتياطي', icon: Database },
    { id: 'email', label: 'البريد الإلكتروني', icon: Mail },
    { id: 'search', label: 'البحث', icon: Search },
    { id: 'privacy', label: 'الخصوصية', icon: Eye }
  ]

  const renderGeneralSettings = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Globe className="h-5 w-5 ml-2" />
            اللغة والمظهر
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>اللغة</Label>
              <select
                className="w-full p-2 border rounded-md"
                value={settings.language}
                onChange={(e) => handleSettingChange('language', e.target.value)}
              >
                <option value="ar">العربية</option>
                <option value="en">English</option>
              </select>
            </div>
            <div>
              <Label>المظهر</Label>
              <select
                className="w-full p-2 border rounded-md"
                value={settings.theme}
                onChange={(e) => handleSettingChange('theme', e.target.value)}
              >
                <option value="light">فاتح</option>
                <option value="dark">داكن</option>
                <option value="auto">تلقائي</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Bell className="h-5 w-5 ml-2" />
            الإشعارات والأصوات
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>تفعيل الإشعارات</Label>
              <p className="text-sm text-gray-600">استقبال إشعارات النظام</p>
            </div>
            <input
              type="checkbox"
              checked={settings.notifications}
              onChange={(e) => handleSettingChange('notifications', e.target.checked)}
              className="w-4 h-4"
            />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <Label>تفعيل الأصوات</Label>
              <p className="text-sm text-gray-600">تشغيل أصوات التنبيه</p>
            </div>
            <input
              type="checkbox"
              checked={settings.soundEnabled}
              onChange={(e) => handleSettingChange('soundEnabled', e.target.checked)}
              className="w-4 h-4"
            />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <Label>الحفظ التلقائي</Label>
              <p className="text-sm text-gray-600">حفظ البيانات تلقائياً</p>
            </div>
            <input
              type="checkbox"
              checked={settings.autoSave}
              onChange={(e) => handleSettingChange('autoSave', e.target.checked)}
              className="w-4 h-4"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderSecuritySettings = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Lock className="h-5 w-5 ml-2" />
            أمان الحساب
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>المصادقة الثنائية</Label>
              <p className="text-sm text-gray-600">طبقة حماية إضافية للحساب</p>
            </div>
            <input
              type="checkbox"
              checked={settings.twoFactorAuth}
              onChange={(e) => handleSettingChange('twoFactorAuth', e.target.checked)}
              className="w-4 h-4"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>انتهاء الجلسة (دقيقة)</Label>
              <Input
                type="number"
                value={settings.sessionTimeout}
                onChange={(e) => handleSettingChange('sessionTimeout', parseInt(e.target.value))}
                min="5"
                max="120"
              />
            </div>
            <div>
              <Label>انتهاء كلمة المرور (يوم)</Label>
              <Input
                type="number"
                value={settings.passwordExpiry}
                onChange={(e) => handleSettingChange('passwordExpiry', parseInt(e.target.value))}
                min="30"
                max="365"
              />
            </div>
          </div>
          
          <div>
            <Label>محاولات تسجيل الدخول المسموحة</Label>
            <Input
              type="number"
              value={settings.loginAttempts}
              onChange={(e) => handleSettingChange('loginAttempts', parseInt(e.target.value))}
              min="3"
              max="10"
            />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-yellow-50 border-yellow-200">
        <CardContent className="p-4">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-yellow-600 ml-2" />
            <div>
              <p className="font-medium text-yellow-900">تحذير أمني</p>
              <p className="text-sm text-yellow-700">تأكد من استخدام كلمة مرور قوية وتفعيل المصادقة الثنائية</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderBackupSettings = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Database className="h-5 w-5 ml-2" />
            إعدادات النسخ الاحتياطي
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>النسخ الاحتياطي التلقائي</Label>
              <p className="text-sm text-gray-600">إنشاء نسخ احتياطية تلقائياً</p>
            </div>
            <input
              type="checkbox"
              checked={settings.autoBackup}
              onChange={(e) => handleSettingChange('autoBackup', e.target.checked)}
              className="w-4 h-4"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>تكرار النسخ الاحتياطي</Label>
              <select
                className="w-full p-2 border rounded-md"
                value={settings.backupFrequency}
                onChange={(e) => handleSettingChange('backupFrequency', e.target.value)}
              >
                <option value="hourly">كل ساعة</option>
                <option value="daily">يومياً</option>
                <option value="weekly">أسبوعياً</option>
                <option value="monthly">شهرياً</option>
              </select>
            </div>
            <div>
              <Label>موقع النسخ الاحتياطي</Label>
              <select
                className="w-full p-2 border rounded-md"
                value={settings.backupLocation}
                onChange={(e) => handleSettingChange('backupLocation', e.target.value)}
              >
                <option value="local">محلي</option>
                <option value="cloud">سحابي</option>
                <option value="both">كلاهما</option>
              </select>
            </div>
          </div>
          
          <div className="flex space-x-4 space-x-reverse">
            <Button onClick={performBackup} disabled={backupStatus === 'loading'}>
              {backupStatus === 'loading' ? (
                <RefreshCw className="h-4 w-4 ml-2 animate-spin" />
              ) : (
                <Download className="h-4 w-4 ml-2" />
              )}
              إنشاء نسخة احتياطية الآن
            </Button>
            <Button variant="outline">
              <Upload className="h-4 w-4 ml-2" />
              استعادة من نسخة احتياطية
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className={`${backupStatus === 'success' ? 'bg-green-50 border-green-200' : 'bg-gray-50'}`}>
        <CardContent className="p-4">
          <div className="flex items-center">
            {backupStatus === 'success' ? (
              <CheckCircle className="h-5 w-5 text-green-600 ml-2" />
            ) : (
              <Clock className="h-5 w-5 text-gray-600 ml-2" />
            )}
            <div>
              <p className="font-medium">آخر نسخة احتياطية</p>
              <p className="text-sm text-gray-600">
                {backupStatus === 'success' ? 'تم بنجاح - منذ دقائق' : 'لم يتم إنشاء نسخة احتياطية بعد'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderEmailSettings = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Mail className="h-5 w-5 ml-2" />
            إعدادات البريد الإلكتروني
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>إشعارات البريد الإلكتروني</Label>
              <p className="text-sm text-gray-600">استقبال إشعارات عبر البريد</p>
            </div>
            <input
              type="checkbox"
              checked={settings.emailNotifications}
              onChange={(e) => handleSettingChange('emailNotifications', e.target.checked)}
              className="w-4 h-4"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label>تقارير البريد الإلكتروني</Label>
              <p className="text-sm text-gray-600">إرسال التقارير عبر البريد</p>
            </div>
            <input
              type="checkbox"
              checked={settings.emailReports}
              onChange={(e) => handleSettingChange('emailReports', e.target.checked)}
              className="w-4 h-4"
            />
          </div>
          
          <div>
            <Label>تكرار التقارير</Label>
            <select
              className="w-full p-2 border rounded-md"
              value={settings.emailFrequency}
              onChange={(e) => handleSettingChange('emailFrequency', e.target.value)}
            >
              <option value="daily">يومياً</option>
              <option value="weekly">أسبوعياً</option>
              <option value="monthly">شهرياً</option>
            </select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>إعدادات خادم SMTP</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>خادم SMTP</Label>
              <Input
                value={settings.smtpServer}
                onChange={(e) => handleSettingChange('smtpServer', e.target.value)}
                placeholder="smtp.gmail.com"
              />
            </div>
            <div>
              <Label>منفذ SMTP</Label>
              <Input
                type="number"
                value={settings.smtpPort}
                onChange={(e) => handleSettingChange('smtpPort', parseInt(e.target.value))}
                placeholder="587"
              />
            </div>
          </div>
          
          <div>
            <Label>اسم المستخدم</Label>
            <Input
              value={settings.smtpUsername}
              onChange={(e) => handleSettingChange('smtpUsername', e.target.value)}
              placeholder="your-email@gmail.com"
            />
          </div>
          
          <div>
            <Label>كلمة المرور</Label>
            <div className="relative">
              <Input
                type={showPassword ? 'text' : 'password'}
                value={settings.smtpPassword}
                onChange={(e) => handleSettingChange('smtpPassword', e.target.value)}
                placeholder="كلمة مرور التطبيق"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute left-3 top-1/2 transform -translate-y-1/2"
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>
          
          <Button onClick={testEmailConnection} variant="outline">
            اختبار الاتصال
          </Button>
        </CardContent>
      </Card>
    </div>
  )

  const renderSearchSettings = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Search className="h-5 w-5 ml-2" />
            إعدادات البحث
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>حفظ تاريخ البحث</Label>
              <p className="text-sm text-gray-600">حفظ عمليات البحث السابقة</p>
            </div>
            <input
              type="checkbox"
              checked={settings.searchHistory}
              onChange={(e) => handleSettingChange('searchHistory', e.target.checked)}
              className="w-4 h-4"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label>اقتراحات البحث</Label>
              <p className="text-sm text-gray-600">عرض اقتراحات أثناء الكتابة</p>
            </div>
            <input
              type="checkbox"
              checked={settings.searchSuggestions}
              onChange={(e) => handleSettingChange('searchSuggestions', e.target.checked)}
              className="w-4 h-4"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label>فهرسة المحتوى</Label>
              <p className="text-sm text-gray-600">فهرسة البيانات لبحث أسرع</p>
            </div>
            <input
              type="checkbox"
              checked={settings.indexing}
              onChange={(e) => handleSettingChange('indexing', e.target.checked)}
              className="w-4 h-4"
            />
          </div>
          
          <div className="pt-4">
            <Button variant="outline">
              <RefreshCw className="h-4 w-4 ml-2" />
              إعادة بناء الفهرس
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderPrivacySettings = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Eye className="h-5 w-5 ml-2" />
            إعدادات الخصوصية
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>جمع البيانات</Label>
              <p className="text-sm text-gray-600">السماح بجمع بيانات الاستخدام</p>
            </div>
            <input
              type="checkbox"
              checked={settings.dataCollection}
              onChange={(e) => handleSettingChange('dataCollection', e.target.checked)}
              className="w-4 h-4"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label>التحليلات</Label>
              <p className="text-sm text-gray-600">إرسال بيانات التحليل</p>
            </div>
            <input
              type="checkbox"
              checked={settings.analytics}
              onChange={(e) => handleSettingChange('analytics', e.target.checked)}
              className="w-4 h-4"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label>موافقة ملفات تعريف الارتباط</Label>
              <p className="text-sm text-gray-600">عرض نافذة موافقة الكوكيز</p>
            </div>
            <input
              type="checkbox"
              checked={settings.cookieConsent}
              onChange={(e) => handleSettingChange('cookieConsent', e.target.checked)}
              className="w-4 h-4"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderTabContent = () => {
    switch (activeTab) {
      case 'general':
        return renderGeneralSettings()
      case 'security':
        return renderSecuritySettings()
      case 'backup':
        return renderBackupSettings()
      case 'email':
        return renderEmailSettings()
      case 'search':
        return renderSearchSettings()
      case 'privacy':
        return renderPrivacySettings()
      default:
        return renderGeneralSettings()
    }
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">الإعدادات</h1>
          <p className="text-gray-600 mt-2">إدارة إعدادات النظام والتفضيلات</p>
        </div>
        <Button onClick={saveSettings}>
          <Save className="h-4 w-4 ml-2" />
          حفظ الإعدادات
        </Button>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar */}
        <div className="lg:w-1/4">
          <Card>
            <CardContent className="p-4">
              <nav className="space-y-2">
                {tabs.map((tab) => {
                  const IconComponent = tab.icon
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center space-x-3 space-x-reverse px-3 py-2 rounded-lg text-right transition-colors ${
                        activeTab === tab.id
                          ? 'bg-blue-100 text-blue-700 border border-blue-200'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      <IconComponent className="h-4 w-4" />
                      <span>{tab.label}</span>
                    </button>
                  )
                })}
              </nav>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:w-3/4">
          {renderTabContent()}
        </div>
      </div>
    </div>
  )
}

export default SettingsComponent

