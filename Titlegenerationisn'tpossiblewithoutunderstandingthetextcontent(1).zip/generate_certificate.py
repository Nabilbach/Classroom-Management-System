from fpdf import FPDF

def generate_certificate(student_name, badge_name, date_awarded, output_path):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 24)
    pdf.cell(0, 80, "Certificate of Achievement", 0, 1, "C")
    pdf.set_font("Arial", "", 16)
    pdf.cell(0, 10, f"This certifies that", 0, 1, "C")
    pdf.set_font("Arial", "B", 20)
    pdf.cell(0, 10, student_name, 0, 1, "C")
    pdf.set_font("Arial", "", 16)
    pdf.cell(0, 10, f"has been awarded the", 0, 1, "C")
    pdf.set_font("Arial", "B", 20)
    pdf.cell(0, 10, badge_name, 0, 1, "C")
    pdf.set_font("Arial", "", 12)
    pdf.cell(0, 40, f"Date Awarded: {date_awarded}", 0, 1, "C")
    pdf.output(output_path)

if __name__ == "__main__":
    # Example usage (for testing purposes)
    generate_certificate("Ahmed Mohamed Ali", "Star Student", "2025-06-23", "./certificate_example.pdf")


