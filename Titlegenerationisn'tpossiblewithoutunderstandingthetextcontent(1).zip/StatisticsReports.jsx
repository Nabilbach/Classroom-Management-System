import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import * as XLSX from 'xlsx'
import jsPDF from 'jspdf'
import 'jspdf-autotable'
import { 
  BarChart3, 
  TrendingUp, 
  Download, 
  Mail,
  Trophy,
  Users,
  Award,
  AlertTriangle,
  Calendar,
  FileText,
  PieChart,
  Target,
  Star
} from 'lucide-react'

const StatisticsReports = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('month')
  const [selectedReport, setSelectedReport] = useState('overview')

  // Sample data for leaderboard
  const leaderboard = [
    {
      rank: 1,
      name: 'فاطمة أحمد حسن',
      section: 'الصف الأول',
      totalPoints: 275,
      participationPoints: 95,
      behaviorPoints: 95,
      homeworkPoints: 85,
      badges: ['متفوقة', 'مبدعة', 'منتظمة'],
      starRating: 5
    },
    {
      rank: 2,
      name: 'أحمد محمد علي',
      section: 'الصف الأول',
      totalPoints: 253,
      participationPoints: 85,
      behaviorPoints: 90,
      homeworkPoints: 78,
      badges: ['مجتهد', 'متعاون'],
      starRating: 4
    },
    {
      rank: 3,
      name: 'عبدالله سالم أحمد',
      section: 'الصف الثالث',
      totalPoints: 248,
      participationPoints: 88,
      behaviorPoints: 85,
      homeworkPoints: 75,
      badges: ['مجتهد', 'مشارك'],
      starRating: 4
    },
    {
      rank: 4,
      name: 'مريم حسن محمد',
      section: 'الصف الثاني',
      totalPoints: 235,
      participationPoints: 80,
      behaviorPoints: 85,
      homeworkPoints: 70,
      badges: ['منتظمة', 'متعاونة'],
      starRating: 4
    },
    {
      rank: 5,
      name: 'يوسف علي حسن',
      section: 'الصف الرابع',
      totalPoints: 228,
      participationPoints: 75,
      behaviorPoints: 80,
      homeworkPoints: 73,
      badges: ['مجتهد'],
      starRating: 3
    }
  ]

  // Sample statistics data
  const statistics = {
    overview: {
      totalStudents: 180,
      excellentStudents: 45,
      averageStudents: 127,
      poorStudents: 8,
      averageGrade: 81,
      attendanceRate: 94,
      homeworkCompletionRate: 87,
      behaviorScore: 89
    },
    sectionPerformance: [
      { section: 'الصف الأول', average: 85, students: 30, excellent: 8, poor: 1 },
      { section: 'الصف الثاني', average: 78, students: 28, excellent: 7, poor: 2 },
      { section: 'الصف الثالث', average: 88, students: 32, excellent: 9, poor: 1 },
      { section: 'الصف الرابع', average: 75, students: 29, excellent: 6, poor: 2 },
      { section: 'الصف الخامس', average: 82, students: 31, excellent: 8, poor: 1 },
      { section: 'الصف السادس', average: 80, students: 30, excellent: 7, poor: 1 }
    ],
    behaviorTrends: [
      { month: 'يناير', excellent: 38, good: 125, poor: 17 },
      { month: 'فبراير', excellent: 42, good: 128, poor: 10 },
      { month: 'مارس', excellent: 45, good: 127, poor: 8 },
      { month: 'أبريل', excellent: 47, good: 125, poor: 8 },
      { month: 'مايو', excellent: 45, good: 127, poor: 8 }
    ]
  }

  const getRankIcon = (rank) => {
    switch (rank) {
      case 1: return '🥇'
      case 2: return '🥈'
      case 3: return '🥉'
      default: return `#${rank}`
    }
  }

  const getPerformanceColor = (average) => {
    if (average >= 85) return 'text-green-600'
    if (average >= 70) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getPerformanceText = (average) => {
    if (average >= 85) return 'ممتاز'
    if (average >= 70) return 'جيد'
    return 'يحتاج تحسين'
  }

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
      />
    ))
  }

  const exportData = (format) => {
    if (format === 'Excel') {
      const ws = XLSX.utils.json_to_sheet(leaderboard);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Leaderboard");
      XLSX.writeFile(wb, "leaderboard.xlsx");
      alert("تم تصدير البيانات إلى Excel بنجاح!");
    } else if (format === 'PDF') {
      const doc = new jsPDF();
      doc.text("Leaderboard Report", 14, 16);
      const tableColumn = ["الترتيب", "الاسم", "القسم", "إجمالي النقاط", "المشاركة", "السلوك", "الواجبات", "البادجات", "التقييم"];
      const tableRows = [];

      leaderboard.forEach(student => {
        const studentData = [
          student.rank,
          student.name,
          student.section,
          student.totalPoints,
          student.participationPoints,
          student.behaviorPoints,
          student.homeworkPoints,
          student.badges.join(", "),
          student.starRating + " نجوم"
        ];
        tableRows.push(studentData);
      });

      doc.autoTable({head: [tableColumn], body: tableRows, startY: 20});
      doc.save("leaderboard.pdf");
      alert("تم تصدير البيانات إلى PDF بنجاح!");
    }
  }

  const sendReport = () => {
    alert("سيتم إرسال التقرير إلى البريد الإلكتروني (هذه الميزة تتطلب إعدادات خادم البريد الإلكتروني)");
  }

  const OverviewReport = () => (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-600">إجمالي التلاميذ</p>
                <p className="text-2xl font-bold text-blue-900">{statistics.overview.totalStudents}</p>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-600">المتفوقون</p>
                <p className="text-2xl font-bold text-green-900">{statistics.overview.excellentStudents}</p>
                <p className="text-xs text-green-600">
                  {Math.round((statistics.overview.excellentStudents / statistics.overview.totalStudents) * 100)}%
                </p>
              </div>
              <Award className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-yellow-600">المعدل العام</p>
                <p className="text-2xl font-bold text-yellow-900">{statistics.overview.averageGrade}%</p>
              </div>
              <Target className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-red-600">يحتاجون تحسين</p>
                <p className="text-2xl font-bold text-red-900">{statistics.overview.poorStudents}</p>
                <p className="text-xs text-red-600">
                  {Math.round((statistics.overview.poorStudents / statistics.overview.totalStudents) * 100)}%
                </p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Section Performance */}
      <Card>
        <CardHeader>
          <CardTitle>أداء الأقسام</CardTitle>
          <CardDescription>مقارنة الأداء بين الأقسام المختلفة</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {statistics.sectionPerformance.map((section, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4 space-x-reverse">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <span className="text-blue-600 font-bold">{index + 1}</span>
                  </div>
                  <div>
                    <h3 className="font-semibold">{section.section}</h3>
                    <p className="text-sm text-gray-600">{section.students} تلميذ</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-6 space-x-reverse">
                  <div className="text-center">
                    <p className="text-sm text-gray-600">المعدل</p>
                    <p className={`font-bold ${getPerformanceColor(section.average)}`}>
                      {section.average}%
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-600">متفوقون</p>
                    <p className="font-bold text-green-600">{section.excellent}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-600">يحتاجون تحسين</p>
                    <p className="font-bold text-red-600">{section.poor}</p>
                  </div>
                  <Badge className={`${
                    section.average >= 85 ? 'bg-green-100 text-green-800' :
                    section.average >= 70 ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {getPerformanceText(section.average)}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Behavior Trends */}
      <Card>
        <CardHeader>
          <CardTitle>اتجاهات السلوك</CardTitle>
          <CardDescription>تطور السلوك على مدار الأشهر الماضية</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {statistics.behaviorTrends.map((trend, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="font-medium">{trend.month}</div>
                <div className="flex items-center space-x-4 space-x-reverse">
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm">ممتاز: {trend.excellent}</span>
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <span className="text-sm">جيد: {trend.good}</span>
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span className="text-sm">يحتاج تحسين: {trend.poor}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const LeaderboardReport = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Trophy className="h-5 w-5 ml-2 text-yellow-600" />
          لوحة الصدارة
        </CardTitle>
        <CardDescription>أفضل التلاميذ أداءً بناءً على النقاط المحصلة</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {leaderboard.map((student, index) => (
            <div key={index} className={`flex items-center justify-between p-4 rounded-lg border-2 ${
              student.rank === 1 ? 'bg-yellow-50 border-yellow-200' :
              student.rank === 2 ? 'bg-gray-50 border-gray-200' :
              student.rank === 3 ? 'bg-orange-50 border-orange-200' :
              'bg-white border-gray-100'
            }`}>
              <div className="flex items-center space-x-4 space-x-reverse">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center text-lg font-bold ${
                  student.rank === 1 ? 'bg-yellow-100 text-yellow-800' :
                  student.rank === 2 ? 'bg-gray-100 text-gray-800' :
                  student.rank === 3 ? 'bg-orange-100 text-orange-800' :
                  'bg-blue-100 text-blue-800'
                }`}>
                  {getRankIcon(student.rank)}
                </div>
                <div>
                  <h3 className="font-semibold text-lg">{student.name}</h3>
                  <p className="text-sm text-gray-600">{student.section}</p>
                  <div className="flex items-center space-x-1 space-x-reverse mt-1">
                    {renderStars(student.starRating)}
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-6 space-x-reverse">
                <div className="text-center">
                  <p className="text-sm text-gray-600">إجمالي النقاط</p>
                  <p className="text-xl font-bold text-blue-600">{student.totalPoints}</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-600">المشاركة</p>
                  <p className="font-medium">{student.participationPoints}%</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-600">السلوك</p>
                  <p className="font-medium">{student.behaviorPoints}%</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-600">الواجبات</p>
                  <p className="font-medium">{student.homeworkPoints}%</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-1">البادجات</p>
                  <div className="flex flex-wrap gap-1">
                    {student.badges.map((badge, badgeIndex) => (
                      <Badge key={badgeIndex} variant="secondary" className="text-xs">
                        {badge}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )

  const renderReport = () => {
    switch (selectedReport) {
      case 'overview':
        return <OverviewReport />
      case 'leaderboard':
        return <LeaderboardReport />
      default:
        return <OverviewReport />
    }
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">الإحصائيات والتقارير</h1>
          <p className="text-gray-600 mt-2">تحليل شامل لأداء التلاميذ والأقسام الدراسية</p>
        </div>
        <div className="flex space-x-4 space-x-reverse">
          <Button variant="outline" onClick={() => exportData('Excel')}>
            <Download className="h-4 w-4 ml-2" />
            تصدير Excel
          </Button>
          <Button variant="outline" onClick={() => exportData('PDF')}>
            <FileText className="h-4 w-4 ml-2" />
            تصدير PDF
          </Button>
          <Button onClick={sendReport}>
            <Mail className="h-4 w-4 ml-2" />
            إرسال بالبريد
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex space-x-4 space-x-reverse">
              <div>
                <label className="text-sm font-medium text-gray-600">نوع التقرير:</label>
                <select
                  className="mr-2 p-2 border rounded-md"
                  value={selectedReport}
                  onChange={(e) => setSelectedReport(e.target.value)}
                >
                  <option value="overview">نظرة عامة</option>
                  <option value="leaderboard">لوحة الصدارة</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">الفترة الزمنية:</label>
                <select
                  className="mr-2 p-2 border rounded-md"
                  value={selectedPeriod}
                  onChange={(e) => setSelectedPeriod(e.target.value)}
                >
                  <option value="week">هذا الأسبوع</option>
                  <option value="month">هذا الشهر</option>
                  <option value="semester">هذا الفصل</option>
                  <option value="year">هذا العام</option>
                </select>
              </div>
            </div>
            
            <div className="flex space-x-2 space-x-reverse">
              <Button
                size="sm"
                variant={selectedReport === 'overview' ? 'default' : 'outline'}
                onClick={() => setSelectedReport('overview')}
              >
                <BarChart3 className="h-4 w-4 ml-1" />
                نظرة عامة
              </Button>
              <Button
                size="sm"
                variant={selectedReport === 'leaderboard' ? 'default' : 'outline'}
                onClick={() => setSelectedReport('leaderboard')}
              >
                <Trophy className="h-4 w-4 ml-1" />
                لوحة الصدارة
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Report Content */}
      {renderReport()}
    </div>
  )
}

export default StatisticsReports

